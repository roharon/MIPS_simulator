#include "MIPS.h"

int fromBinary(const char* s) {
	return (int)strtol(s, NULL, 2);
}