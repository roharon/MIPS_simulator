int sum(int a, int b);

int sum(int a, int b) {
	return a + b;
}