void aaa__aaa() {
	return 1;
}