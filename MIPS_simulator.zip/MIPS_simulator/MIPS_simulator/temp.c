#include "MIPS.h"

void aaprint() {
	printf("aaa");
}